import { createFileRoute } from "@tanstack/react-router";
import { CakeSlice, Heart, Instagram, Mail, MapPin, Sparkles, Youtube } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { TestimonialsCarousel } from "@/components/testimonials-carousel";
import { ScrollProgress } from "@/components/scroll-progress";
import { BackToTop } from "@/components/back-to-top";
import { Sprinkles } from "@/components/sprinkles";
import { MarqueeStrip } from "@/components/marquee-strip";



import logo from "@/assets/karis-logo.jpg.asset.json";
import bakerPhoto from "@/assets/karis-baker.png.asset.json";
import weddingCake from "@/assets/karis-wedding-cake.png.asset.json";
import birthday from "@/assets/karis-birthday-cake.png.asset.json";
import sugarFloral from "@/assets/karis-sugar-floral.png.asset.json";
import cupcakes from "@/assets/karis-cupcakes.png.asset.json";
import graduation from "@/assets/karis-graduation.png.asset.json";
import servingsChart from "@/assets/karis-servings-chart.png.asset.json";
import tieredCakes from "@/assets/karis-tiered-cakes.png.asset.json";


export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Karis Cakes | Handcrafted Cakes for Every Celebration" },
      {
        name: "description",
        content:
          "Karis Cakes creates handcrafted wedding, birthday and celebration cakes, cupcakes and dessert tables. Order your custom cake today.",
      },
      { property: "og:title", content: "Karis Cakes | Handcrafted Cakes for Every Celebration" },
      {
        property: "og:description",
        content:
          "Custom wedding, birthday and celebration cakes made with real butter, fresh cream and a lot of love.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const INSTAGRAM_URL = "https://www.instagram.com/kariscakesofficial/";
const YOUTUBE_URL = "https://www.youtube.com/@KarisCakesOfficial";

const gallery = [
  { src: weddingCake.url, alt: "White wedding cake with sugar peonies, gold accents and a bride and groom topper", label: "Wedding Cakes" },
  { src: birthday.url, alt: "Emerald green and gold marbled birthday cake with sphere decorations", label: "Birthday" },
  { src: sugarFloral.url, alt: "Pink and white tiered cake with sugar florals, a gilded frame and a large bow", label: "Sugar floral" },
  { src: cupcakes.url, alt: "Cupcake bouquet with buttercream roses and hydrangeas wrapped in gold-trimmed paper", label: "Cupcakes" },
  { src: graduation.url, alt: "Cream graduation cake with a fondant cap, gears, a diploma scroll and monogram details", label: "Graduations" },
  { src: tieredCakes.url, alt: "Sculptural tiered cake with sugar florals, textured panels and mixed marble tiers", label: "Tiered-Cakes", contain: true },
];


const menu = [
  {
    icon: Heart,
    title: "Cakes",
  },
  {
    icon: Sparkles,
    title: "Made for you",
    decorative: true,
  },
  {
    icon: Heart,
    title: "Cupcakes",
  },
];

const sectionIds = ["menu", "flavours", "servings", "gallery", "about", "order"];

function useActiveSection(ids: string[]) {
  const [active, setActive] = useState<string>(ids[0] ?? "");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) {
          setActive(visible.target.id);
        }
      },
      {
        rootMargin: "-20% 0px -55% 0px",
        threshold: [0, 0.25, 0.5, 0.75, 1],
      }
    );

    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [ids]);

  return active;
}




function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    el.classList.add("opacity-0", "translate-y-10");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.remove("opacity-0", "translate-y-10");
            entry.target.classList.add("reveal-up");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -50px 0px" }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return ref;
}

function RevealSection({
  children,
  className = "",
  ...props
}: React.HTMLAttributes<HTMLElement> & { children: React.ReactNode }) {
  const ref = useScrollReveal();
  return (
    <section ref={ref} className={className} {...props}>
      {children}
    </section>
  );
}

function Index() {



  const activeSection = useActiveSection(sectionIds);

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <a href="#top" className="flex items-center gap-3">
            <img
              src={logo.url}
              alt="Karis Cakes logo"
              width={44}
              height={44}
              className="spin-hover h-11 w-11 rounded-full object-cover"
            />
            <span className="font-display text-lg tracking-[0.2em] text-primary sm:text-xl">
              KARIS CAKES
            </span>
          </a>
          <div className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
            <a
              href="#menu"
              className={`nav-glow fx-underline-slide rounded-full px-3 py-1 transition-colors hover:text-primary ${activeSection === "menu" ? "nav-link-active" : ""}`}
            >
              Menu
            </a>
            <a
              href="#flavours"
              className={`nav-glow fx-underline-slide rounded-full px-3 py-1 transition-colors hover:text-primary ${activeSection === "flavours" ? "nav-link-active" : ""}`}
            >
              Flavours
            </a>
            <a
              href="#servings"
              className={`nav-glow fx-underline-slide rounded-full px-3 py-1 transition-colors hover:text-primary ${activeSection === "servings" ? "nav-link-active" : ""}`}
            >
              Servings
            </a>
            <a
              href="#gallery"
              className={`nav-glow fx-underline-slide rounded-full px-3 py-1 transition-colors hover:text-primary ${activeSection === "gallery" ? "nav-link-active" : ""}`}
            >
              Gallery
            </a>
            <a
              href="#about"
              className={`nav-glow fx-underline-slide rounded-full px-3 py-1 transition-colors hover:text-primary ${activeSection === "about" ? "nav-link-active" : ""}`}
            >
              Testimonials
            </a>
            <a
              href="#order"
              className={`nav-glow fx-underline-slide rounded-full px-3 py-1 transition-colors hover:text-primary ${activeSection === "order" ? "nav-link-active" : ""}`}
            >
              Order
            </a>
          </div>

          <a
            href="#order"
            className="press shine pulse-ring fx-ring-hover fx-letter-spread rounded-full bg-primary-gradient px-5 py-2 text-sm font-medium text-primary-foreground shadow-soft"
          >
            Order a cake
          </a>
        </nav>
        <ScrollProgress />
      </header>

      <main id="top">
        <RevealSection className="relative overflow-hidden bg-hero-gradient">
          <Sprinkles />
          <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-5 py-16 md:grid-cols-2 md:py-24">
            <div>
              <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-card/70 px-4 py-1.5 text-xs uppercase tracking-[0.25em] text-primary">
                <Sparkles className="h-3.5 w-3.5" /> Baked to order
              </p>
              <h1 className="font-display text-5xl leading-[1.05] text-foreground md:text-7xl">
                Karis
                <span className="block font-script text-6xl text-gradient-animated md:text-8xl">Cakes</span>
              </h1>
              <figure className="mt-6 max-w-md border-l-2 border-primary/40 pl-5">
                <blockquote className="font-quote text-2xl leading-snug text-foreground md:text-3xl">
                  &ldquo;Taste and see that the Lord is good; blessed is the one who takes refuge
                  in Him.&rdquo;
                </blockquote>
                <figcaption className="mt-3 text-sm uppercase tracking-[0.2em] text-muted-foreground">
                  Psalm 34:8
                </figcaption>
              </figure>

              <div className="mt-8 flex flex-wrap gap-3">
                <a
                  href="#order"
                  className="press shine rounded-full bg-primary-gradient px-7 py-3 text-sm font-medium text-primary-foreground shadow-soft"
                >
                  Enquire now
                </a>
                <a
                  href="#gallery"
                  className="press fx-lift-lg fx-border-glow fx-letter-spread rounded-full border border-primary/30 bg-card px-7 py-3 text-sm font-medium text-primary hover:bg-secondary"
                >
                  See the cakes
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -left-6 -top-6 h-32 w-32 animate-aurora rounded-full bg-accent/70 blur-2xl" />
              <div className="absolute -bottom-8 -right-4 h-40 w-40 animate-float rounded-full bg-secondary blur-3xl" />
              <img
                src={bakerPhoto.url}
                alt="Karis Cakes baker in a custom linen apron"
                width={1400}
                height={1200}
                className="tilt-hover relative w-full rounded-[2rem] border border-card object-cover shadow-card"
              />
            </div>
          </div>
          <div className="relative flex justify-center pb-8">
            <a
              href="#menu"
              aria-label="Scroll to menu"
              className="animate-bob inline-flex h-10 w-10 items-center justify-center rounded-full border border-primary/30 bg-card/80 text-primary shadow-soft backdrop-blur"
            >
              <CakeSlice className="h-4 w-4" />
            </a>
          </div>
        </RevealSection>

        <MarqueeStrip />

        {/* Menu */}
        <RevealSection id="menu" className="mx-auto max-w-6xl px-5 py-20">
          <div className="mx-auto max-w-xl text-center">
            <p className="fx-slide-in fx-letter-spread text-xs uppercase tracking-[0.3em] text-primary">The menu</p>
            <h2 className="heading-underline sheen-text fx-gradient-text-hover mt-3 text-4xl">Made for your moment</h2>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {menu.map((item) => (
              <article
                key={item.title}
                className={`shine group rounded-3xl border border-border p-8 transition-all hover:-translate-y-1 hover:shadow-card ${
                  item.decorative
                    ? "relative overflow-hidden bg-lavender"
                    : "bg-card"
                }`}
              >
                <span
                  className={`inline-flex h-12 w-12 items-center justify-center rounded-2xl transition-colors ${
                    item.decorative
                      ? "bg-lavender-foreground/10 text-lavender-foreground"
                      : "bg-secondary text-secondary-foreground group-hover:bg-accent group-hover:text-accent-foreground"
                  }`}
                >
                  <item.icon className="h-5 w-5 wobble-hover fx-swing-hover" />
                </span>
                <h3 className={`mt-5 text-2xl ${item.decorative ? "text-lavender-foreground" : "text-card-foreground"}`}>
                  {item.title}
                </h3>
                {item.decorative && (
                  <>
                    <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-lavender-foreground/20 blur-3xl" />
                    <div className="absolute -bottom-8 -left-8 h-32 w-32 rounded-full bg-lavender-foreground/15 blur-2xl" />
                  </>
                )}
              </article>
            ))}
          </div>
        </RevealSection>

        {/* Flavours */}
        <RevealSection id="flavours" className="bg-secondary/30 py-20">
          <div className="mx-auto max-w-6xl px-5">
            <div className="mx-auto max-w-xl text-center">
              <p className="fx-slide-in fx-letter-spread text-xs uppercase tracking-[0.3em] text-primary">Flavours</p>
              <h2 className="heading-underline fx-gradient-text-hover mt-3 text-4xl text-foreground">Pick your favourite</h2>
            </div>
            <div className="mt-12 grid gap-6 md:grid-cols-2">
              <article className="glow-on-hover rounded-3xl border border-border bg-card p-8 shadow-soft transition-transform hover:-translate-y-1">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary text-secondary-foreground">
                  <CakeSlice className="h-5 w-5" />
                </span>
                <h3 className="mt-5 text-2xl text-card-foreground">Basic</h3>
                <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                  {["Vanilla", "Chocolate", "Red Velvet", "Strawberry"].map((flavor) => (
                    <li
                      key={flavor}
                      className="flex items-center gap-3 rounded-2xl border border-border bg-background px-4 py-3 text-sm text-foreground"
                    >
                      <span className="h-2 w-2 rounded-full bg-primary" />
                      {flavor}
                    </li>
                  ))}
                </ul>
              </article>
              <article className="shimmer-gold glow-on-hover relative overflow-hidden rounded-3xl border border-border bg-gold p-8 shadow-soft transition-transform hover:-translate-y-1">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gold-foreground/10 text-gold-foreground">
                  <CakeSlice className="h-5 w-5" />
                </span>
                <h3 className="mt-5 text-2xl text-gold-foreground">Premium</h3>
                <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                  {[
                    "Carrot Cake",
                    "Fruit Cake",
                    "Salted Caramel",
                    "Lemon Cake",
                    "Coconut Cake",
                    "Cookies and Cream Cake",
                  ].map((flavor) => (
                    <li
                      key={flavor}
                      className="flex items-center gap-3 rounded-2xl border border-border/60 bg-background/80 px-4 py-3 text-sm text-foreground"
                    >
                      <span className="h-2 w-2 rounded-full bg-gold-foreground" />
                      {flavor}
                    </li>
                  ))}
                </ul>
                <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold-foreground/20 blur-3xl" />
                <div className="absolute -bottom-8 -left-8 h-32 w-32 rounded-full bg-gold-foreground/15 blur-2xl" />
              </article>

            </div>
          </div>
        </RevealSection>

        {/* Servings */}
        <RevealSection id="servings" className="bg-blush py-20">
          <div className="mx-auto max-w-6xl px-5">
            <div className="mx-auto max-w-xl text-center">
              <p className="fx-slide-in fx-letter-spread text-xs uppercase tracking-[0.3em] text-primary">Servings</p>
              <h2 className="heading-underline fx-gradient-text-hover mt-3 text-4xl text-foreground">Cake sizes & servings</h2>
              <p className="mt-4 text-sm text-muted-foreground">
                A helpful guide to choose the perfect cake for your guest list.
              </p>
            </div>
            <figure className="mx-auto mt-12 max-w-2xl overflow-hidden rounded-3xl border border-border bg-blush p-4 shadow-soft sm:p-6">
              <img
                src={servingsChart.url}
                alt="Cake serving size chart showing tier combinations and guest servings"
                loading="lazy"
                width={1200}
                height={1600}
                className="mx-auto w-full max-w-xl rounded-2xl bg-background object-contain transition-transform duration-500 hover:scale-[1.03]"
              />
              <figcaption className="sr-only">
                Cake servings chart: 2 layer, 4 inch high tiers with 1-1/2 x 2 inch slices
              </figcaption>
            </figure>
          </div>
        </RevealSection>

        {/* Gallery */}
        <RevealSection id="gallery" className="bg-secondary/30 py-20">
          <div className="mx-auto max-w-6xl px-5">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="fx-slide-in fx-letter-spread text-xs uppercase tracking-[0.3em] text-primary">Gallery</p>
                <h2 className="heading-underline fx-gradient-text-hover mt-3 text-4xl text-foreground">Fresh from the kitchen</h2>
              </div>
              <a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noreferrer"
                className="fx-lift-lg fx-rotate-icon fx-letter-spread inline-flex items-center gap-2 rounded-full border border-primary/30 bg-card px-5 py-2 text-sm text-primary transition-colors hover:bg-card/70"
              >
                <Instagram className="h-4 w-4" /> @kariscakes
              </a>
            </div>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {gallery.map((shot, i) => (
                <figure
                  key={shot.label}
                  style={{ animationDelay: `${i * 90}ms` }}
                  className="shine spotlight gradient-frame lift-3d tilt-in halo-pulse fx-scale-in-img fx-hue-hover group relative overflow-hidden rounded-3xl bg-card shadow-soft glow-on-hover"
                >
                  <img
                    src={shot.src}
                    alt={shot.alt}
                    loading="lazy"
                    width={1000}
                    height={1000}
                    className={
                      shot.contain
                        ? "zoom-soft h-72 w-full bg-secondary/40 object-contain p-3"
                        : "ken-burns h-72 w-full object-cover"
                    }
                  />
                  <span className="sheen-sweep pointer-events-none absolute inset-0" aria-hidden="true" />
                  <figcaption className="glass-card caption-rise absolute inset-x-0 bottom-0 flex items-center gap-2 px-5 py-3 text-sm text-card-foreground">
                    <Sparkles className="icon-pop h-3.5 w-3.5 text-primary" />
                    {shot.label}
                  </figcaption>

                </figure>
              ))}

              <figure className="shine gradient-frame lift-3d group relative overflow-hidden rounded-3xl bg-accent shadow-soft glow-on-hover lg:col-span-2">
                <div className="flex h-72 w-full flex-col items-center justify-center gap-4 p-8 text-center">
                  <div className="flex items-center gap-2 text-accent-foreground">
                    <Sparkles className="animate-twinkle h-4 w-4" />
                    <span className="text-xs uppercase tracking-[0.3em]">Karis Cakes</span>
                    <Sparkles className="animate-twinkle h-4 w-4" />
                  </div>
                  <p className="font-script text-4xl text-fuchsia-deep md:text-5xl">
                    Baked with love
                  </p>
                  <p className="max-w-xs text-sm text-accent-foreground">
                    Sweet batches, real butter, and a design made just for you.
                  </p>
                </div>
                <div className="absolute -right-10 -top-10 h-40 w-40 animate-aurora rounded-full bg-butter/60 blur-3xl" />
                <div className="absolute -bottom-8 -left-8 h-32 w-32 animate-aurora rounded-full bg-secondary/60 blur-2xl" />
              </figure>
              <figure className="shine gradient-frame lift-3d group relative overflow-hidden rounded-3xl bg-lavender shadow-soft glow-on-hover lg:col-start-3 lg:row-span-2 lg:row-start-2">
                <div className="flex h-full w-full flex-col items-center justify-center gap-5 p-8 text-center">
                  <div className="flex items-center gap-2 text-lavender-foreground">
                    <Sparkles className="animate-twinkle h-4 w-4" />
                    <span className="text-xs uppercase tracking-[0.3em]">Karis Cakes</span>
                    <Sparkles className="animate-twinkle h-4 w-4" />
                  </div>
                  <p className="font-script text-4xl text-lavender-foreground md:text-5xl">
                    Custom designs
                  </p>
                  <p className="max-w-xs text-sm text-lavender-foreground">
                    Every cake is sketched, baked, and decorated with your celebration in mind.
                  </p>
                </div>
                <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-lavender-foreground/20 blur-3xl" />
                <div className="absolute -bottom-8 -left-8 h-32 w-32 rounded-full bg-lavender-foreground/15 blur-2xl" />
              </figure>
            </div>
          </div>
        </RevealSection>

        {/* Testimonials */}
        <RevealSection id="about" className="mx-auto max-w-6xl px-5 py-20">
          <div className="mx-auto max-w-xl text-center">
            <p className="fx-slide-in fx-letter-spread text-xs uppercase tracking-[0.3em] text-primary">TESTIMONIALS</p>
            <h2 className="heading-underline fx-gradient-text-hover mt-3 text-4xl text-foreground">What our customers say</h2>
          </div>
          <TestimonialsCarousel />

        </RevealSection>

        {/* Order */}
        <RevealSection id="order" className="bg-hero-gradient py-20">
          <div className="mx-auto max-w-3xl px-5 text-center">
            <p className="fx-slide-in fx-letter-spread text-xs uppercase tracking-[0.3em] text-primary">Order</p>
            <h2 className="heading-underline fx-gradient-text-hover mt-3 text-4xl text-foreground">Let&apos;s bake something pretty</h2>
            <p className="mx-auto mt-4 max-w-lg text-muted-foreground">
              Tell us the date, the flavor and the vibe — we&apos;ll send back a design.
              Two weeks&apos; notice is ideal for each order.
            </p>
            <div className="mt-9 grid gap-4 sm:grid-cols-3">
              <a
                href="mailto:kariscakesofficial@gmail.com"
                className="press shine fx-lift-lg fx-border-glow fx-rotate-icon flex flex-col items-center justify-center gap-2 rounded-3xl border border-border bg-card px-5 py-6"
              >
                <Mail className="h-5 w-5 text-primary fx-float" />
                <span className="text-sm text-card-foreground">kariscakesofficial@gmail.com</span>
              </a>
              <a
                href="https://submit.jotform.com//241423927945564"
                target="_blank"
                rel="noreferrer"
                className="press shine fx-lift-lg fx-shadow-pulse flex flex-col items-center justify-center gap-2 rounded-3xl bg-primary-gradient px-5 py-6 text-sm font-medium text-primary-foreground shadow-soft"
              >
                Order Link
              </a>
              <div className="grid gap-4">
                <a
                  href={INSTAGRAM_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="press shine flex flex-col items-center justify-center gap-2 rounded-3xl border border-border bg-card px-5 py-6"
                >
                  <Instagram className="h-5 w-5 text-primary fx-heartbeat-hover" />
                  <span className="text-sm text-card-foreground">DM @kariscakes</span>
                </a>
                <a
                  href={YOUTUBE_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="press shine flex flex-col items-center justify-center gap-2 rounded-3xl border border-border bg-card px-5 py-6"
                >
                  <Youtube className="h-5 w-5 text-primary fx-blink" />
                  <span className="text-sm text-card-foreground">Karis Cakes on YouTube</span>
                </a>
              </div>
            </div>
            <p className="mt-8 inline-flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4 text-primary fx-float" /> Every delivery is at variable cost.
            </p>
          </div>
        </RevealSection>
      </main>

      <footer className="border-t border-border bg-card py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-5 text-center">
          <img
            src={logo.url}
            alt="Karis Cakes logo"
            loading="lazy"
            width={64}
            height={64}
            className="h-16 w-16 rounded-full object-cover"
          />
          <p className="font-script text-2xl text-primary">Karis Cakes</p>
          <p className="text-xs text-muted-foreground">
            © Karis Cakes. Baked fresh, always.
          </p>
        </div>
      </footer>
    <BackToTop />
    </div>
  );
}
