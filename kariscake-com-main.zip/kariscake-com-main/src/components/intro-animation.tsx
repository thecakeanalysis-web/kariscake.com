import { useState } from "react";
import logo from "@/assets/karis-logo.jpg.asset.json";

export function IntroAnimation() {
  const [visible, setVisible] = useState(true);

  if (!visible) {
    return null;
  }

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-blush animate-intro-curtain"
      onAnimationEnd={() => setVisible(false)}
    >
      <div className="relative z-10 flex flex-col items-center text-center px-6">
        <img
          src={logo.url}
          alt="Karis Cakes"
          width={140}
          height={140}
          className="h-32 w-32 rounded-full object-cover animate-intro-logo"
        />
        <h1 className="mt-6 font-display text-4xl tracking-[0.2em] text-foreground animate-intro-text">
          KARIS <span className="text-primary">CAKES</span>
        </h1>
        <p
          className="mt-3 font-script text-2xl text-fuchsia-deep animate-intro-text"
          style={{ animationDelay: "0.15s" }}
        >
          Baked with love
        </p>
      </div>
    </div>
  );
}
