const SPRINKLES = [
  { left: "6%", delay: "0s", duration: "9s", color: "bg-primary/50", size: "h-2 w-1" },
  { left: "18%", delay: "1.6s", duration: "11s", color: "bg-accent", size: "h-2.5 w-1" },
  { left: "31%", delay: "3.1s", duration: "8.5s", color: "bg-secondary", size: "h-2 w-1" },
  { left: "44%", delay: "0.8s", duration: "12s", color: "bg-primary/40", size: "h-3 w-1" },
  { left: "57%", delay: "2.4s", duration: "10s", color: "bg-accent", size: "h-2 w-1" },
  { left: "69%", delay: "4.2s", duration: "9.5s", color: "bg-secondary", size: "h-2.5 w-1" },
  { left: "81%", delay: "1.2s", duration: "13s", color: "bg-primary/45", size: "h-2 w-1" },
  { left: "93%", delay: "3.6s", duration: "10.5s", color: "bg-accent", size: "h-3 w-1" },
];

export function Sprinkles() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {SPRINKLES.map((s) => (
        <span
          key={s.left}
          className={`animate-sprinkle absolute top-0 rounded-full ${s.color} ${s.size}`}
          style={{ left: s.left, animationDelay: s.delay, animationDuration: s.duration }}
        />
      ))}
    </div>
  );
}
