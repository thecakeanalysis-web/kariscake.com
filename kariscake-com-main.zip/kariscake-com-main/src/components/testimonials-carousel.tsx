import { useCallback, useEffect, useRef, useState } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  "Check out our delicious cake! Thanks so much, sis. We really enjoyed this cake. My son was very happy with the colors and design. It was very rich and creamy. I woke up for a midnight snack and was glad I had some left from the party. More sales in Jesus' name!",
  "Thank you for making the cake for my wife's birthday. My wife really loved your cake. Our friends who came over to celebrate loved it as well. We all liked the fact that it wasn't overly sugary or too sweet. The sweetness was just perfect for the occasion. Also, the cake tasted very rich and exceptional. We loved the buttercream flavor and coating. In fact, it was a very beautiful cake with an excellent touch of culinary skill. My friends will also be reaching out to you whenever they need cakes for their upcoming parties and occasions. Thank you.",
  "Thank you so much for making this cake with so much love. It was very well detailed, just as I wanted. The cake is not just beautiful; it's also very 😋😋 yummy, and everyone at home loved it. We will definitely be coming back!",
  "The cake tasted really good. The colors looked so beautiful. My girls loved it so much. One good, big cake for two—it makes sense. Thank you!",
];

const AUTOPLAY_MS = 6000;

export function TestimonialsCarousel() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const touchStart = useRef<number | null>(null);

  const go = useCallback((next: number) => {
    setIndex(((next % testimonials.length) + testimonials.length) % testimonials.length);
  }, []);

  useEffect(() => {
    if (paused) return;
    const id = window.setInterval(() => {
      setIndex((i) => (i + 1) % testimonials.length);
    }, AUTOPLAY_MS);
    return () => window.clearInterval(id);
  }, [paused]);

  return (
    <div
      className="relative mt-12"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={() => setPaused(false)}
      role="region"
      aria-roledescription="carousel"
      aria-label="Customer testimonials"
    >
      <div
        className="overflow-hidden rounded-3xl"
        onTouchStart={(e) => {
          touchStart.current = e.touches[0]?.clientX ?? null;
          setPaused(true);
        }}
        onTouchEnd={(e) => {
          const start = touchStart.current;
          const end = e.changedTouches[0]?.clientX ?? null;
          touchStart.current = null;
          setPaused(false);
          if (start === null || end === null) return;
          const delta = end - start;
          if (Math.abs(delta) > 40) go(index + (delta < 0 ? 1 : -1));
        }}
      >
        <div
          className="flex transition-transform duration-700 ease-[cubic-bezier(0.2,0.8,0.2,1)]"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {testimonials.map((text, i) => (
            <figure
              key={i}
              aria-hidden={i !== index}
              className="w-full shrink-0 grow-0 basis-full bg-cream px-6 py-10 text-center sm:px-14"
            >
              <Quote className="mx-auto h-8 w-8 text-primary/60" />
              <blockquote className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-card-foreground">
                {text}
              </blockquote>
              <figcaption className="mt-6 text-xs uppercase tracking-wider text-muted-foreground">
                — Happy customer
              </figcaption>
            </figure>
          ))}
        </div>
      </div>

      <button
        type="button"
        aria-label="Previous testimonial"
        onClick={() => go(index - 1)}
        className="absolute left-1 top-1/2 -translate-y-1/2 rounded-full border border-border bg-card p-2 text-primary shadow-soft transition-transform hover:-translate-y-[calc(50%+2px)] sm:-left-4"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button
        type="button"
        aria-label="Next testimonial"
        onClick={() => go(index + 1)}
        className="absolute right-1 top-1/2 -translate-y-1/2 rounded-full border border-border bg-card p-2 text-primary shadow-soft transition-transform hover:-translate-y-[calc(50%+2px)] sm:-right-4"
      >
        <ChevronRight className="h-5 w-5" />
      </button>

      <div className="mt-6 flex justify-center gap-2">
        {testimonials.map((_, i) => (
          <button
            key={i}
            type="button"
            aria-label={`Go to testimonial ${i + 1}`}
            aria-current={i === index}
            onClick={() => go(i)}
            className={`h-2 rounded-full transition-all duration-300 ${
              i === index ? "w-8 bg-primary-gradient" : "w-2 bg-secondary hover:bg-primary/50"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
