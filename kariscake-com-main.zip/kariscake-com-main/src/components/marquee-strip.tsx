const ITEMS = [
  "Wedding tiers",
  "Birthday cakes",
  "Sugar florals",
  "Cupcake bouquets",
  "Graduation cakes",
  "Custom designs",
];

export function MarqueeStrip() {
  const loop = [...ITEMS, ...ITEMS];

  return (
    <div
      aria-hidden
      className="relative flex overflow-hidden border-y border-border bg-blush/60 py-3"
    >
      <div className="marquee-track flex min-w-full shrink-0 items-center gap-10 px-5">
        {loop.map((item, i) => (
          <span
            key={`${item}-${i}`}
            className="flex items-center gap-10 whitespace-nowrap text-xs uppercase tracking-[0.35em] text-primary"
          >
            {item}
            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
          </span>
        ))}
      </div>
      <div className="marquee-track flex min-w-full shrink-0 items-center gap-10 px-5">
        {loop.map((item, i) => (
          <span
            key={`b-${item}-${i}`}
            className="flex items-center gap-10 whitespace-nowrap text-xs uppercase tracking-[0.35em] text-primary"
          >
            {item}
            <span className="h-1.5 w-1.5 rounded-full bg-accent" />
          </span>
        ))}
      </div>
    </div>
  );
}
